package main

import (
	"bufio"
	"fmt"
	"os"
	"strconv"
	"strings"
)

// Convertidor contiene las funciones de lógica de conversión
type Convertidor struct{}

// Convertir transforma un valor de una base a otra
func (c *Convertidor) Convertir(valor string, baseOrigen int, baseDestino int) (string, error) {
	// 1. Convertir el string de entrada a un entero decimal (base 10)
	numeroDecimal, err := strconv.ParseInt(valor, baseOrigen, 64)
	if err != nil {
		return "", err
	}

	// 2. Convertir el entero decimal al string de la base destino
	resultado := strconv.FormatInt(numeroDecimal, baseDestino)

	// Para hexadecimal, convertimos a mayúsculas para consistencia
	if baseDestino == 16 {
		resultado = strings.ToUpper(resultado)
	}

	return resultado, nil
}

// ValidarInput verifica si el string es válido para la base indicada
func (c *Convertidor) ValidarInput(valor string, base int) bool {
	// Intentamos parsear. Si devuelve error, no es válido para esa base.
	_, err := strconv.ParseInt(valor, base, 64)
	return err == nil
}

func mostrarMenu() {
	fmt.Println("\n" + strings.Repeat("=", 40))
	fmt.Println("   CONVERTIDOR DE SISTEMAS NUMÉRICOS")
	fmt.Println(strings.Repeat("=", 40))
	fmt.Println("1. Decimal a Binario")
	fmt.Println("2. Decimal a Octal")
	fmt.Println("3. Decimal a Hexadecimal")
	fmt.Println("4. Binario a Decimal")
	fmt.Println("5. Octal a Decimal")
	fmt.Println("6. Hexadecimal a Decimal")
	fmt.Println("7. Conversión Personalizada (Cualquiera a Cualquiera)")
	fmt.Println("0. Salir")
	fmt.Println(strings.Repeat("=", 40))
	fmt.Print("Seleccione una opción: ")
}

func leerEntrada(reader *bufio.Reader) string {
	texto, _ := reader.ReadString('\n')
	return strings.TrimSpace(texto)
}

func main() {
	convertidor := Convertidor{}
	reader := bufio.NewReader(os.Stdin)

	for {
		mostrarMenu()
		opcion := leerEntrada(reader)

		switch opcion {
		case "1": // Dec -> Bin
			fmt.Print("Ingrese número decimal: ")
			val := leerEntrada(reader)
			if convertidor.ValidarInput(val, 10) {
				res, _ := convertidor.Convertir(val, 10, 2)
				fmt.Printf("Resultado: %s (Binario)\n", res)
			} else {
				fmt.Println("Error: Entrada no válida para decimal.")
			}

		case "2": // Dec -> Oct
			fmt.Print("Ingrese número decimal: ")
			val := leerEntrada(reader)
			if convertidor.ValidarInput(val, 10) {
				res, _ := convertidor.Convertir(val, 10, 8)
				fmt.Printf("Resultado: %s (Octal)\n", res)
			} else {
				fmt.Println("Error: Entrada no válida para decimal.")
			}

		case "3": // Dec -> Hex
			fmt.Print("Ingrese número decimal: ")
			val := leerEntrada(reader)
			if convertidor.ValidarInput(val, 10) {
				res, _ := convertidor.Convertir(val, 10, 16)
				fmt.Printf("Resultado: %s (Hexadecimal)\n", res)
			} else {
				fmt.Println("Error: Entrada no válida para decimal.")
			}

		case "4": // Bin -> Dec
			fmt.Print("Ingrese número binario: ")
			val := leerEntrada(reader)
			if convertidor.ValidarInput(val, 2) {
				res, _ := convertidor.Convertir(val, 2, 10)
				fmt.Printf("Resultado: %s (Decimal)\n", res)
			} else {
				fmt.Println("Error: Entrada no válida para binario (solo 0 y 1).")
			}

		case "5": // Oct -> Dec
			fmt.Print("Ingrese número octal: ")
			val := leerEntrada(reader)
			if convertidor.ValidarInput(val, 8) {
				res, _ := convertidor.Convertir(val, 8, 10)
				fmt.Printf("Resultado: %s (Decimal)\n", res)
			} else {
				fmt.Println("Error: Entrada no válida para octal (0-7).")
			}

		case "6": // Hex -> Dec
			fmt.Print("Ingrese número hexadecimal: ")
			val := leerEntrada(reader)
			if convertidor.ValidarInput(val, 16) {
				res, _ := convertidor.Convertir(val, 16, 10)
				fmt.Printf("Resultado: %s (Decimal)\n", res)
			} else {
				fmt.Println("Error: Entrada no válida para hexadecimal.")
			}

		case "7": // Personalizada
			fmt.Print("Número a convertir: ")
			val := leerEntrada(reader)
			
			fmt.Print("Base de origen (2, 8, 10, 16): ")
			baseOrigenStr := leerEntrada(reader)
			baseOrigen, err := strconv.Atoi(baseOrigenStr)
			
			fmt.Print("Base de destino (2, 8, 10, 16): ")
			baseDestinoStr := leerEntrada(reader)
			baseDestino, err2 := strconv.Atoi(baseDestinoStr)

			basesValidas := []int{2, 8, 10, 16}
			esBaseOrigenValida := contiene(basesValidas, baseOrigen)
			esBaseDestinoValida := contiene(basesValidas, baseDestino)

			if err == nil && err2 == nil && esBaseOrigenValida && esBaseDestinoValida {
				if convertidor.ValidarInput(val, baseOrigen) {
					res, errConv := convertidor.Convertir(val, baseOrigen, baseDestino)
					if errConv != nil {
						fmt.Println("Error en la conversión:", errConv)
					} else {
						fmt.Printf("Resultado: %s\n", res)
					}
				} else {
					fmt.Printf("El número no es válido para la base de origen %d.\n", baseOrigen)
				}
			} else {
				fmt.Println("Bases no soportadas o entrada inválida.")
			}

		case "0":
			fmt.Println("Saliendo del programa...")
			return
		default:
			fmt.Println("Opción no válida.")
		}
	}
}

// Función auxiliar para verificar si un slice contiene un entero
func contiene(slice []int, elemento int) bool {
	for _, item := range slice {
		if item == elemento {
			return true
		}
	}
	return false
}