module numeric

go 1.25.0
