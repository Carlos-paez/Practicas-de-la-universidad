class ConvertidorNumerico
  # Método principal para convertir
  def self.convertir(valor, base_origen, base_destino)
    begin
      # 1. Convertir el string de entrada a un entero decimal (base 10)
      # to_i(base) interpreta el string según la base dada
      numero_decimal = valor.to_i(base_origen)

      # 2. Convertir el entero decimal al string de la base destino
      # to_s(base) convierte el número a string en la base dada
      resultado = numero_decimal.to_s(base_destino).upcase

      return resultado
    rescue => e
      return "Error: #{e.message}"
    end
  end

  # Método para validar si el input es correcto para esa base
  def self.validar_input(valor, base)
    case base
    when 2  # Binario
      return valor.match?(/^[01]+$/)
    when 8  # Octal
      return valor.match?(/^[0-7]+$/)
    when 10 # Decimal
      return valor.match?(/^[0-9]+$/)
    when 16 # Hexadecimal
      return valor.match?(/^[0-9a-fA-F]+$/)
    else
      return false
    end
  end
end

# --- Interfaz de Usuario (Menú) ---

def mostrar_menu
  puts "\n" + "="*40
  puts "   CONVERTIDOR DE SISTEMAS NUMÉRICOS"
  puts "="*40
  puts "1. Decimal a Binario"
  puts "2. Decimal a Octal"
  puts "3. Decimal a Hexadecimal"
  puts "4. Binario a Decimal"
  puts "5. Octal a Decimal"
  puts "6. Hexadecimal a Decimal"
  puts "7. Conversión Personalizada (Cualquiera a Cualquiera)"
  puts "0. Salir"
  puts "="*40
  print "Seleccione una opción: "
end

loop do
  mostrar_menu
  opcion = gets.chomp

  case opcion
  when '1' # Dec -> Bin
    print "Ingrese número decimal: "
    val = gets.chomp
    if ConvertidorNumerico.validar_input(val, 10)
      puts "Resultado: #{ConvertidorNumerico.convertir(val, 10, 2)} (Binario)"
    else
      puts "Error: Entrada no válida para decimal."
    end

  when '2' # Dec -> Oct
    print "Ingrese número decimal: "
    val = gets.chomp
    if ConvertidorNumerico.validar_input(val, 10)
      puts "Resultado: #{ConvertidorNumerico.convertir(val, 10, 8)} (Octal)"
    else
      puts "Error: Entrada no válida para decimal."
    end

  when '3' # Dec -> Hex
    print "Ingrese número decimal: "
    val = gets.chomp
    if ConvertidorNumerico.validar_input(val, 10)
      puts "Resultado: #{ConvertidorNumerico.convertir(val, 10, 16)} (Hexadecimal)"
    else
      puts "Error: Entrada no válida para decimal."
    end

  when '4' # Bin -> Dec
    print "Ingrese número binario: "
    val = gets.chomp
    if ConvertidorNumerico.validar_input(val, 2)
      puts "Resultado: #{ConvertidorNumerico.convertir(val, 2, 10)} (Decimal)"
    else
      puts "Error: Entrada no válida para binario (solo 0 y 1)."
    end

  when '5' # Oct -> Dec
    print "Ingrese número octal: "
    val = gets.chomp
    if ConvertidorNumerico.validar_input(val, 8)
      puts "Resultado: #{ConvertidorNumerico.convertir(val, 8, 10)} (Decimal)"
    else
      puts "Error: Entrada no válida para octal (0-7)."
    end

  when '6' # Hex -> Dec
    print "Ingrese número hexadecimal: "
    val = gets.chomp
    if ConvertidorNumerico.validar_input(val, 16)
      puts "Resultado: #{ConvertidorNumerico.convertir(val, 16, 10)} (Decimal)"
    else
      puts "Error: Entrada no válida para hexadecimal."
    end
    
  when '7' # Personalizada
    print "Número a convertir: "
    val = gets.chomp
    print "Base de origen (2, 8, 10, 16): "
    base_orig = gets.chomp.to_i
    print "Base de destino (2, 8, 10, 16): "
    base_dest = gets.chomp.to_i
    
    if [2, 8, 10, 16].include?(base_orig) && [2, 8, 10, 16].include?(base_dest)
       if ConvertidorNumerico.validar_input(val, base_orig)
         puts "Resultado: #{ConvertidorNumerico.convertir(val, base_orig, base_dest)}"
       else
         puts "El número no es válido para la base de origen #{base_orig}."
       end
    else
      puts "Bases no soportadas."
    end

  when '0'
    puts "Saliendo del programa..."
    break
  else
    puts "Opción no válida."
  end
end