<?php

    namespace php;

    require_once 'ClassEstudiantes.php';

    for ($i=0; $i < 3; $i++) {

            echo("Ingrese el nombre del estudiante:\n");
            $name=readline();

            echo("Ingrese el apellido del estudiante:\n");
            $lastname=readline();

            echo("Ingrese la edad del estudiante:\n");
            $edad=readline();

            echo("Ingrese el día en que ingresó del estudiante:\n");
            $ingreso=readline();



            $estudiante = new classEstudiantes($name,$lastname, $edad, $ingreso);


            $estudiante->saludar();

            $estudiante->mayorEdad();

            echo ("El estudiante ingreso el día: ");
            $estudiante->diaIngreso();

            sleep(1);

            echo("\n\n\n\n");
    }
?>