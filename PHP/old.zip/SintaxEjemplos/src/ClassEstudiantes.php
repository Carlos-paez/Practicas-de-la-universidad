<?php

namespace php;

class classEstudiantes
{
    private $nombre;
    private $apellido;
    private $edad;

    private $ingreso;

    function __construct($nombre, $apellido, $edad, $ingreso){
        $this->nombre = $nombre;
        $this->apellido = $apellido;
        $this->edad = $edad;
        $this->ingreso = $ingreso;
    }

    public function getNombre(){
        return $this->nombre;
    }
    public function getApellido(){
        return $this->apellido;
    }
    public function getEdad(){
        return $this->edad;
    }
    public function getIngreso(){
        return $this->ingreso;
    }
    public function setNombre($nombre){
        $this->nombre = $nombre;
    }
    public function setApellido($apellido){
        $this->apellido = $apellido;
    }
    public function setEdad($edad){
        $this->edad = $edad;
    }
    public function setIngreso($ingreso){
        $this->ingreso = $ingreso;
    }





    public function saludar()
    {
        echo "El es $this->nombre $this->apellido y tiene $this->edad\n";
    }

    public function mayorEdad()
    {
        if($this->edad > 18){
            echo ("Es mayor de edad\n");
        }
        else{
            echo ("Es menor de edad\n");
        }
    }

    public function diaIngreso()
    {
        switch ($this->ingreso) {
            case "lunes":
                echo "Lunes";
                break;

            case "martes":
                echo "Martes";
                break;

            case "miercoles":
                echo "Miercoles";
                break;

            case "jueves":
                echo "Jueves";
                break;

            case "viernes":
                echo "Viernes";
                break;

            case "sabado":
                echo "Sabado";
                break;

            default:
                echo "No a ingresado";
        }
    }
}
?>