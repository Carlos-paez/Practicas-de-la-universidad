<?php

class estudiante
{
    private $nombre;

    function __construct($nombre)
    {
        $this->nombre = $nombre;
    }

    public function getNombre(){
        return $this->nombre;
    }

    public function setNombre($nombre){
        $this->nombre = $nombre;
    }

    public function saludar(){
        echo "hola soy ".$this->nombre."\n\n";
    }
}

?>