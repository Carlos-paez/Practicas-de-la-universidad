<?php

    namespace mvc;

    use estudiante;

    require_once 'modelo/usuarios.php';

    echo "nombre:\n";
    $name = readline();

    $estudiante = new estudiante($name);

    $estudiante->saludar();

    $estudiante->setNombre("carlos");
    echo ("lo cambie a carlos\n");
    $estudiante->saludar();

?>